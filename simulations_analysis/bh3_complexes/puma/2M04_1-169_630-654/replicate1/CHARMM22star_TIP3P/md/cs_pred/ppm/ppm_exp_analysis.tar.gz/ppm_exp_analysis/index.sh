
path_tpr=../../../../../../../../../../simulations/bh3_complexes/puma/2M04_1-169_630-654/replicate1/CHARMM22star_TIP3P/md/md.tpr


echo "a 1-2640\nq\n"|gmx make_ndx -f $path_tpr #only analysis for Bclxl
