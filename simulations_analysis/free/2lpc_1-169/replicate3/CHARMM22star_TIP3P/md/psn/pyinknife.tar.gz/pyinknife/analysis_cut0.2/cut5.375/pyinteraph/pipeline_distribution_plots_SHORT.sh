#!/bin/bash

## Script created to plot the distribution figures from the PyInKnife
#    Copyright (C) 2016 Juan Salamanca Viloria <juan.salamanca.viloria@gmail.com>, Elena Papaleo <elenap@cancer.dk>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.

#   You should have received a copy of the GNU General Public License
#   along with this program.  If not, see <http://www.gnu.org/licenses/>.

cd contact/$1/

python2.7 ../../all_plot_hubs.py hubs_list.out ../../resampling*/contact/$1/hubs_list.out -x ../../$2 -hb $3


python2.7 ../../all_plot_cmap.py component_contact.out ../../resampling*/contact/$1/component_contact.out -x ../../$2 -hb $3

Rscript ../../all_hubs_distribution.R distribution_hubs.txt

Rscript ../../all_cmap_distribution.R final_cmap.txt 
