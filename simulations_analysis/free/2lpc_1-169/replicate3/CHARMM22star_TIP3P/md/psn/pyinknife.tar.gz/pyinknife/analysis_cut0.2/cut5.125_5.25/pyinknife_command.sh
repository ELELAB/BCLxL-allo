python2.7 PyInKnife.py -f ../../../traj_c22st_2nm_cap.xtc -s ../../../md_prot_cap.tpr -cut_off 5.125 -cut_off2 5.250 -ff charmm27 -k 3 -hb no -x rmsd.xvg -jackknife -filter 20 <<eof
keep 1
q
eof
